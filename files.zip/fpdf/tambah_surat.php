<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $no_surat_tugas = $_POST['no_surat_tugas'];
    $tanggal_surat = $_POST['tanggal_surat'];
    $uraian = $_POST['uraian'];
    $tujuan = $_POST['tujuan'];

    $stmt = $conn->prepare("INSERT INTO surat_tugas VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $no_surat_tugas, $tanggal_surat, $uraian, $tujuan);

    if ($stmt->execute()) {
        header("Location: tambah_sppd.php");
        exit;
    } else {
        echo "Gagal: " . $conn->error;
    }
}
?>
<form method="POST">
    No Surat Tugas: <input type="text" name="no_surat_tugas" required><br>
    Tanggal Surat: <input type="date" name="tanggal_surat" required><br>
    Uraian: <input type="text" name="uraian" required><br>
    Tujuan: <input type="text" name="tujuan" required><br>
    <button type="submit">Simpan</button>
</form>
