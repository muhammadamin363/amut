<?php
ob_start(); // cegah output sebelum PDF

require('fpdf/fpdf.php');
include 'db.php';

// Fungsi untuk mengganti dash aneh jadi hyphen biasa
function fix_dash($text) {
    return str_replace(["–", "—"], "-", $text);
}

class PDF extends FPDF {
    function Header() {
        global $widths; // supaya bisa akses array widths
        $this->SetFont('Arial','B',14);
        $this->Cell(0,10,'Data Perjalanan Dinas',0,1,'C');
        $this->Ln(5);

        // Judul Kolom
        $this->SetFont('Arial','B',10);
        $this->SetFillColor(200,220,255);

        $headers = ['No','No Surat','Tanggal','No SPPD','Nama','Pangkat/Gol','Jabatan','Uraian','Tujuan'];
        $alignHeader = ['C','C','C','C','C','C','C','C','C'];

        for ($i=0; $i<count($headers); $i++) {
            $this->Cell($widths[$i], 10, $headers[$i], 1, 0, $alignHeader[$i], true);
        }
        $this->Ln();
    }

    function FancyRow($data, $widths, $aligns) {
        $nb = 0;
        for($i=0;$i<count($data);$i++) {
            $nb = max($nb, $this->NbLines($widths[$i], $data[$i]));
        }
        $h = 6 * $nb;
        $this->CheckPageBreak($h);
        for($i=0;$i<count($data);$i++) {
            $w = $widths[$i];
            $a = isset($aligns[$i]) ? $aligns[$i] : 'L'; // default kiri
            $x = $this->GetX();
            $y = $this->GetY();
            $this->Rect($x, $y, $w, $h);
            $this->MultiCell($w, 6, $data[$i], 0, $a);
            $this->SetXY($x + $w, $y);
        }
        $this->Ln($h);
    }

    function CheckPageBreak($h) {
        if($this->GetY() + $h > $this->PageBreakTrigger)
            $this->AddPage($this->CurOrientation);
    }

    function NbLines($w, $txt) {
        $cw = &$this->CurrentFont['cw'];
        if ($w == 0)
            $w = $this->w - $this->rMargin - $this->x;
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if ($nb > 0 and $s[$nb - 1] == "\n")
            $nb--;
        $sep = -1;
        $i = 0;
        $j = 0;
        $l = 0;
        $nl = 1;
        while ($i < $nb) {
            $c = $s[$i];
            if ($c == "\n") {
                $i++;
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
                continue;
            }
            if ($c == ' ')
                $sep = $i;
            $l += $cw[$c];
            if ($l > $wmax) {
                if ($sep == -1) {
                    if ($i == $j)
                        $i++;
                } else {
                    $i = $sep + 1;
                }
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
            } else {
                $i++;
            }
        }
        return $nl;
    }
}

// Lebar kolom
$widths = [10, 35, 25, 20, 50, 25, 60, 75, 40];

// Alignment kolom: L=left, C=center, R=right
$aligns = ['C','L','C','C','L','C','L','L','L'];

// Ambil data dari database
$result = mysqli_query($conn, "SELECT * FROM dinas ORDER BY id ASC");

$pdf = new PDF('L','mm','Legal');
$pdf->SetMargins(10,10,10);
$pdf->AddPage();
$pdf->SetFont('Arial','',10);

// Inisialisasi nomor urut
$no = 1;

while ($row = mysqli_fetch_assoc($result)) {
    $pdf->FancyRow([
        $no++,
        fix_dash($row['no_surat_tugas']),
        date('d-m-Y', strtotime($row['tanggal_surat'])),
        fix_dash($row['no_sppd']),
        fix_dash($row['nama']),
        fix_dash($row['pangkat_gol']),
        fix_dash($row['jabatan']),
        fix_dash($row['uraian']),
        fix_dash($row['tujuan'])
    ], $widths, $aligns);
}

$pdf->Output('I', 'data_perjalanan_dinas.pdf');
ob_end_flush();
