<?php
$filename = $_GET['file'] ?? '';
$tempPath = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $filename;

if (!file_exists($tempPath)) {
    die("❌ File tidak ditemukan.");
}

header("Content-Description: File Transfer");
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
readfile($tempPath);
exit;
