<?php
include 'db.php';

// Ambil nomor urut terbesar dari no_surat_tugas
$query = "SELECT MAX(CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(no_surat_tugas, '/', 2), '/', -1) AS UNSIGNED)) AS max_no FROM dinas";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);
$nextNo = $data['max_no'] ? $data['max_no'] + 1 : 1;

// Format nomor surat tugas
$noSurat = "800.1.11.1/" . str_pad($nextNo, 2, '0', STR_PAD_LEFT) . "/CAU";

// Ambil No SPPD terakhir
$querySppd = "SELECT MAX(CAST(no_sppd AS UNSIGNED)) AS max_sppd FROM dinas";
$resultSppd = mysqli_query($conn, $querySppd);
$dataSppd = mysqli_fetch_assoc($resultSppd);
$nextSppd = $dataSppd['max_sppd'] ? $dataSppd['max_sppd'] + 1 : 1;

// Format No SPPD (misal 01, 02, 03)
$noSppd = str_pad($nextSppd, 2, '0', STR_PAD_LEFT);

// Proses simpan
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $no_sppd       = $_POST['no_sppd'];
    $tanggal_surat = $_POST['tanggal_surat'];
    $nama          = $_POST['nama'];
    $pangkat_gol   = $_POST['pangkat_gol'];
    $jabatan       = $_POST['jabatan'];
    $uraian        = $_POST['uraian'];
    $tujuan        = $_POST['tujuan'];

    $query = "INSERT INTO dinas (no_surat_tugas, no_sppd, tanggal_surat, nama, pangkat_gol, jabatan, uraian, tujuan)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssssss", $noSurat, $no_sppd, $tanggal_surat, $nama, $pangkat_gol, $jabatan, $uraian, $tujuan);

    if ($stmt->execute()) {
        header("Location: index.php");
        exit();
    } else {
        echo "Gagal menyimpan data: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Form Input Perjalanan Dinas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Form Tambah Data Perjalanan Dinas</h2>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">No Surat Tugas</label>
            <input type="text" class="form-control" name="no_surat_tugas" value="<?= $noSurat ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Tanggal Surat</label>
            <input type="date" class="form-control" name="tanggal_surat" required>
        </div>
        <div class="mb-3">
            <label class="form-label">No SPPD</label>
            <input type="text" class="form-control" name="no_sppd" value="<?= $noSppd ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Nama Pegawai</label>
            <select class="form-control" name="nama" id="namaPegawai" required>
                <option value="">-- Pilih Pegawai --</option>
                <?php
                $pegawai = mysqli_query($conn, "SELECT * FROM pegawai ORDER BY nama ASC");
                while ($p = mysqli_fetch_assoc($pegawai)) {
                    echo "<option value='{$p['nama']}' data-pangkat='{$p['pangkat']}' data-jabatan='{$p['jabatan']}'>{$p['nama']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Pangkat/Gol</label>
            <input type="text" class="form-control" name="pangkat_gol" id="pangkat" readonly required>
        </div>
        <div class="mb-3">
            <label class="form-label">Jabatan</label>
            <input type="text" class="form-control" name="jabatan" id="jabatan" readonly required>
        </div>
        <div class="mb-3">
            <label class="form-label">Uraian</label>
            <input type="text" class="form-control" name="uraian" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Tujuan</label>
            <input type="text" class="form-control" name="tujuan" required>
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
    </form>

    <script>
    document.getElementById('namaPegawai').addEventListener('change', function() {
        let selected = this.options[this.selectedIndex];
        document.getElementById('pangkat').value = selected.getAttribute('data-pangkat') || '';
        document.getElementById('jabatan').value = selected.getAttribute('data-jabatan') || '';
    });
    </script>
</body>
</html>
