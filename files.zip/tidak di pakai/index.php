<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Perjalanan Dinas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Data Perjalanan Dinas</h2>
    <a href="form_input.php" class="btn btn-primary mb-3">+ Tambah Data</a>
    <br>
    <a href="cetak_pdf.php" target="_blank" class="btn btn-success mb-3">🖨️ Cetak Halaman (PDF)</a>
    </br>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>No Surat Tugas</th>
                <th>Tanggal Surat</th>
                <th>No SPPD</th>
                <th>Nama</th>
                <th>Pangkat/Gol</th>
                <th>Jabatan</th>
                <th>Uraian</th>
                <th>Tujuan</th>
                <th>Aksi</th> <!-- Dipindahkan ke paling kanan -->
            </tr>
        </thead>
        <tbody>
        <?php
        $no = 1;
        $result = mysqli_query($conn, "SELECT * FROM dinas ORDER BY id ASC");
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $no++ . "</td>";
            echo "<td>{$row['no_surat_tugas']}</td>";
            echo "<td>{$row['tanggal_surat']}</td>";
            echo "<td>{$row['no_sppd']}</td>";
            echo "<td>{$row['nama']}</td>";
            echo "<td>{$row['pangkat_gol']}</td>";
            echo "<td>{$row['jabatan']}</td>";
            echo "<td>{$row['uraian']}</td>";
            echo "<td>{$row['tujuan']}</td>";
            echo "<td>
                    <a href='edit.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                    <a href='hapus.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick=\"return confirm('Yakin hapus?')\">Hapus</a>
                    <a href='cetak_spdf.php?no_surat_tugas={$row['no_surat_tugas']}' class='btn btn-outline-success btn-sm'>Print</a>
                  </td>"; // Dipindahkan ke paling akhir
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</body>
</html>
