<?php
ob_start();
require('fpdf/fpdf.php');
include 'db.php';

// Fungsi tanggal Indonesia
function tanggal_indo($tanggal) {
    $bulan = [
        1 => 'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    ];
    $pecah = explode('-', $tanggal);
    return (int)$pecah[2] . ' ' . $bulan[(int)$pecah[1]] . ' ' . $pecah[0];
}

// Fungsi perbaikan dash menjadi hyphen biasa
function fix_dash($text) {
    return str_replace(["–", "—"], "-", $text);
}

$no_surat_tugas = $_GET['no_surat_tugas'] ?? '';
if (!$no_surat_tugas) {
    die("❌ Nomor Surat Tugas tidak ditemukan.");
}

class PDF extends FPDF {
    function Header() {
        // Logo
        $this->Image('logo.png', 15, 10, 20); 

        // Kop surat
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 6, 'PEMERINTAH KABUPATEN HULU SUNGAI UTARA', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 6, 'KECAMATAN AMUNTAI UTARA', 0, 1, 'C');

        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 5, 'Jln. Amuntai - Tanjung Km. 7,5 Desa Teluk Daun Telp. (0527) 83055', 0, 1, 'C');
        $this->Cell(0, 5, 'Kabupaten Hulu Sungai Utara, Provinsi Kalimantan Selatan', 0, 1, 'C');
        $this->Cell(0, 5, 'Email: kantorkecamatanamuntaiutara@gmail.com  Kode Pos 71471', 0, 1, 'C');

        // Garis bawah kop surat
        $this->Ln(2);
        $this->SetLineWidth(0.8);
        $this->Line(10, $this->GetY(), 200, $this->GetY());
        $this->SetLineWidth(0.2);
        $this->Ln(8);
    }
}

// Ambil data surat
$stmt = $conn->prepare("SELECT * FROM dinas WHERE no_surat_tugas = ? LIMIT 1");
$stmt->bind_param("s", $no_surat_tugas);
$stmt->execute();
$data_surat = $stmt->get_result()->fetch_assoc();
if (!$data_surat) {
    die("❌ Data surat tugas tidak ditemukan.");
}

// Ambil data petugas pertama + NIP dari tabel pegawai
$stmt2 = $conn->prepare("
    SELECT d.*, p.nip 
    FROM dinas d
    LEFT JOIN pegawai p ON d.nama = p.nama
    WHERE d.no_surat_tugas = ?
    LIMIT 1
");
$stmt2->bind_param("s", $no_surat_tugas);
$stmt2->execute();
$petugas = $stmt2->get_result()->fetch_assoc();

$pdf = new PDF('P', 'mm', 'A4');
$pdf->SetMargins(15, 10, 15);
$pdf->AddPage();

// Judul
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 7, fix_dash('LAPORAN HASIL PERJALANAN DINAS'), 0, 1, 'C');
$pdf->Ln(5);

// Pembuka
$pdf->SetFont('Arial', '', 11);
$pdf->MultiCell(0, 6, fix_dash("Berdasarkan Surat Perintah Perjalanan Dinas :"));
$pdf->Ln(2);

// Isi Laporan
$pdf->Cell(40, 6, 'Nomor', 0, 0);
$pdf->Cell(5, 6, ':', 0, 0);
$pdf->Cell(0, 6, fix_dash($data_surat['no_surat_tugas']), 0, 1);

$pdf->Cell(40, 6, 'Tanggal', 0, 0);
$pdf->Cell(5, 6, ':', 0, 0);
$pdf->Cell(0, 6, tanggal_indo(date('Y-m-d', strtotime($data_surat['tanggal_surat']))), 0, 1);

$pdf->Cell(40, 6, 'Tujuan', 0, 0);
$pdf->Cell(5, 6, ':', 0, 0);
$pdf->Cell(0, 6, fix_dash($data_surat['tujuan']), 0, 1);

$pdf->Cell(40, 6, 'Keperluan', 0, 0);
$pdf->Cell(5, 6, ':', 0, 0);
$pdf->MultiCell(0, 6, fix_dash($data_surat['uraian']), 0, 'L');

$pdf->Cell(40, 6, 'Dengan Hasil', 0, 0);
$pdf->Cell(5, 6, ':', 0, 0);
$pdf->MultiCell(0, 6, fix_dash("Telah Melaksanakan {$data_surat['uraian']} Bertempat di {$data_surat['tujuan']} pada tanggal " . tanggal_indo(date('Y-m-d', strtotime($data_surat['tanggal_surat'])))), 0, 'L');

// ===== Bagian Tanda Tangan (posisi manual) =====
$pdf->Ln(15);
$pdf->SetFont('Arial', '', 11);

$posisiX = 110; // atur posisi manual

$pdf->SetX($posisiX);
$pdf->Cell(0, 6, 'Teluk Daun, ' . tanggal_indo(date('Y-m-d', strtotime($data_surat['tanggal_surat']))), 0, 1, 'C');

$pdf->SetX($posisiX);
$pdf->Cell(0, 6, 'Yang Melaporkan,', 0, 1, 'C');

$pdf->Ln(20);

$pdf->SetFont('Arial', 'B', 11);
$pdf->SetX($posisiX);
$pdf->Cell(0, 6, fix_dash($petugas['nama']), 0, 1, 'C');

$pdf->SetFont('Arial', '', 11);
$pdf->SetX($posisiX);
$pdf->Cell(0, 6, 'NIP. ' . ($petugas['nip'] ?? '-'), 0, 1, 'C');

$pdf->Output('I', 'laporan_perjalanan_' . $no_surat_tugas . '.pdf');
ob_end_flush();
?>
