<?php
include 'db.php';

// Ambil data berdasarkan ID
$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM dinas WHERE id = $id");
$data = mysqli_fetch_assoc($result);

// Proses update saat form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data yang boleh diubah dari POST
    $no_sppd = $_POST['no_sppd'];
    $nama = $_POST['nama'];
    $pangkat_gol = $_POST['pangkat_gol'];
    $jabatan = $_POST['jabatan'];
    $uraian = $_POST['uraian'];
    $tujuan = $_POST['tujuan'];

    $query = "UPDATE dinas SET 
                no_sppd = '$no_sppd',
                nama = '$nama',
                pangkat_gol = '$pangkat_gol',
                jabatan = '$jabatan',
                uraian = '$uraian',
                tujuan = '$tujuan'
              WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        header("Location: index.php");
        exit();
    } else {
        echo "Gagal memperbarui data: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Edit Data Perjalanan Dinas</h2>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">No Surat Tugas</label>
            <input type="text" class="form-control" name="no_surat_tugas" value="<?= htmlspecialchars($data['no_surat_tugas']) ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">Tanggal Surat</label>
            <input type="date" class="form-control" name="tanggal_surat" value="<?= htmlspecialchars($data['tanggal_surat']) ?>" readonly>
        </div>
        <div class="mb-3">
            <label class="form-label">No SPPD</label>
            <input type="text" class="form-control" name="no_sppd" value="<?= htmlspecialchars($data['no_sppd']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Nama</label>
            <input type="text" class="form-control" name="nama" value="<?= htmlspecialchars($data['nama']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Pangkat/Gol</label>
            <input type="text" class="form-control" name="pangkat_gol" value="<?= htmlspecialchars($data['pangkat_gol']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Jabatan</label>
            <input type="text" class="form-control" name="jabatan" value="<?= htmlspecialchars($data['jabatan']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Uraian</label>
            <input type="text" class="form-control" name="uraian" value="<?= htmlspecialchars($data['uraian']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Tujuan</label>
            <input type="text" class="form-control" name="tujuan" value="<?= htmlspecialchars($data['tujuan']) ?>" required>
        </div>
        <button type="submit" class="btn btn-success">Update</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
    </form>
</body>
</html>
