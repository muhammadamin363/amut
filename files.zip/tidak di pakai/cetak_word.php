<?php
require 'vendor/autoload.php';
include 'db.php';

use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\IOFactory;

$no_surat = $_GET['id'] ?? '';
if (!$no_surat) {
    die("❌ Nomor surat tugas tidak ditemukan.");
}

$sql = "SELECT * FROM dinas WHERE no_surat_tugas = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $no_surat);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("❌ Data tidak ditemukan.");
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}
$surat = $data[0];

// Buat file Word
$phpWord = new PhpWord();
$section = $phpWord->addSection();

// Kop dan isi surat...
$section->addText("PEMERINTAH DAERAH KABUPATEN CONTOH", ['bold' => true, 'size' => 14], ['alignment' => 'center']);
$section->addText("DINAS PERJALANAN DINAS", ['bold' => true, 'size' => 12], ['alignment' => 'center']);
$section->addText("Jl. Contoh Raya No.123", [], ['alignment' => 'center']);
$section->addLine(['weight' => 1, 'width' => 450, 'color' => '000000']);
$section->addTextBreak(1);

$section->addText("SURAT TUGAS", ['bold' => true, 'size' => 14, 'underline' => 'single'], ['alignment' => 'center']);
$section->addText("Nomor: " . $surat['no_surat_tugas'], [], ['alignment' => 'center']);
$section->addTextBreak(1);

$section->addText("Memberikan tugas kepada:");
foreach ($data as $i => $row) {
    $section->addText(($i+1) . ". Nama: {$row['nama']}");
    $section->addText("   Pangkat: {$row['pangkat_gol']}");
    $section->addText("   Jabatan: {$row['jabatan']}");
    $section->addText("   No SPPD: {$row['no_sppd']}");
    $section->addTextBreak(0.5);
}
$section->addText("Untuk melaksanakan tugas sesuai dengan arahan.", [], ['alignment' => 'both']);
$section->addTextBreak(1);

$section->addText("Dikeluarkan di: Contoh", [], ['alignment' => 'left']);
$section->addText("Tanggal: " . date('d-m-Y'), [], ['alignment' => 'left']);
$section->addTextBreak(2);
$section->addText("Kepala Dinas", [], ['alignment' => 'left']);
$section->addTextBreak(3);
$section->addText("_______________________", [], ['alignment' => 'left']);

// Simpan ke folder public (misal: files/)
$filename = 'Surat_Tugas_' . str_replace('/', '_', $no_surat) . '.docx';
$filepath = 'files/' . $filename;
$writer = IOFactory::createWriter($phpWord, 'Word2007');
$writer->save($filepath);

// Tampilkan link untuk lihat dan download
echo "<h2>✅ Surat Tugas berhasil dibuat</h2>";
echo "<iframe src='$filepath' width='100%' height='600px' style='border:1px solid #ccc'></iframe><br><br>";
echo "<a href='$filepath' download class='btn btn-primary'>📥 Download Surat Word</a>";
