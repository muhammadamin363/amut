<?php
include 'db.php';

$id       = $_POST['id'];
$no_surat = $_POST['no_surat'];
$no_sppd  = $_POST['no_sppd'];
$tanggal  = $_POST['tanggal_surat'];
$nama     = $_POST['nama'];
$pangkat  = $_POST['pangkat'];
$jabatan  = $_POST['jabatan'];
$uraian   = $_POST['uraian'];
$tujuan   = $_POST['tujuan'];

$query = "UPDATE dinas SET
    no_surat_tugas='$no_surat',
    no_sppd='$no_sppd',
    tanggal_surat='$tanggal',
    nama='$nama',
    pangkat_gol='$pangkat',
    jabatan='$jabatan',
    uraian='$uraian',
    tujuan='$tujuan'
    WHERE id=$id";

mysqli_query($conn, $query);
header("Location: index.php");
?>
