<?php
require('fpdf/fpdf.php');
include 'db.php';

$no_surat_tugas = $_GET['no_surat_tugas'];

// Ambil data surat
$surat = $conn->query("SELECT * FROM surat_tugas WHERE no_surat_tugas='$no_surat_tugas'")->fetch_assoc();

// Ambil daftar petugas
$petugas = $conn->query("SELECT * FROM sppd WHERE no_surat_tugas='$no_surat_tugas' ORDER BY no_sppd");

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,"Surat Tugas: {$surat['no_surat_tugas']}",0,1,'C');

$pdf->SetFont('Arial','',12);
$pdf->Cell(0,8,"Tanggal: {$surat['tanggal_surat']}",0,1);
$pdf->Cell(0,8,"Uraian: {$surat['uraian']}",0,1);
$pdf->Cell(0,8,"Tujuan: {$surat['tujuan']}",0,1);
$pdf->Ln(5);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(20,8,"No",1);
$pdf->Cell(40,8,"NIP",1);
$pdf->Cell(50,8,"Nama",1);
$pdf->Cell(40,8,"Pangkat/Gol",1);
$pdf->Cell(40,8,"Jabatan",1);
$pdf->Ln();

$pdf->SetFont('Arial','',10);
while ($row = $petugas->fetch_assoc()) {
    $pdf->Cell(20,8,$row['no_sppd'],1);
    $pdf->Cell(40,8,$row['nip'],1);
    $pdf->Cell(50,8,$row['nama'],1);
    $pdf->Cell(40,8,$row['pangkat_gol'],1);
    $pdf->Cell(40,8,$row['jabatan'],1);
    $pdf->Ln();
}

$pdf->Output();
