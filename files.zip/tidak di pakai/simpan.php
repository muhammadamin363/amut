<?php
include 'db.php';

$no_surat = $_POST['no_surat'];
$no_sppd = $_POST['no_sppd'];
$tanggal = $_POST['tanggal_surat'];
$nama = $_POST['nama'];
$pangkat = $_POST['pangkat'];
$jabatan = $_POST['jabatan'];
$uraian = $_POST['uraian'];
$tujuan = $_POST['tujuan'];

$total = count($nama);

for ($i = 0; $i < $total; $i++) {
    $query = "INSERT INTO dinas (no_surat_tugas, no_sppd, tanggal_surat, nama, pangkat_gol, jabatan, uraian, tujuan) VALUES (
        '{$no_surat[$i]}',
        '{$no_sppd[$i]}',
        '{$tanggal[$i]}',
        '{$nama[$i]}',
        '{$pangkat[$i]}',
        '{$jabatan[$i]}',
        '{$uraian[$i]}',
        '{$tujuan[$i]}'
    )";
    mysqli_query($conn, $query);
}

header("Location: index.php");
?>
