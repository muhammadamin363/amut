<?php
include 'db.php';  // pastikan file ini ada dan koneksi benar

if (!isset($_GET['id'])) {
    die("ID tidak ditemukan");  // cek apakah id sudah dikirim
}

$id = intval($_GET['id']);  // ubah id jadi angka, amankan dari SQL Injection

if ($id <= 0) {
    die("ID tidak valid");
}

$query = "DELETE FROM dinas WHERE id = $id";  // query hapus

if (mysqli_query($conn, $query)) {
    header("Location: index.php");
    exit;
} else {
    echo "Gagal menghapus data: " . mysqli_error($conn);
}
?>
